-- pdb_top_sqls.sql
-- Top SQLs for a given PDB (CON_ID). Set v_con_id as the PDB CON_ID.
DEFINE v_con_id = '&&con_id'
SELECT sql_id, plan_hash_value, executions, elapsed_time/NULLIF(executions,0) avg_elapsed,
       buffer_gets, disk_reads
FROM v$sql
WHERE con_id = &v_con_id
ORDER BY elapsed_time DESC
FETCH FIRST 50 ROWS ONLY;
