-- awr_diff_pdbs.sql
-- Compare AWR top SQL between two snapshots for a specific CON_ID (PDB)
-- Edit the variables below: set v_dbid, v_inst_id, v_con_id, v_snap1, v_snap2
DEFINE v_dbid = '&&dbid'
DEFINE v_inst_id = '&&inst_id'
DEFINE v_con_id = '&&con_id'
DEFINE v_snap1 = '&&snap1'
DEFINE v_snap2 = '&&snap2'

SELECT /*+ ordered */ s.snap_id, ss.sql_id, ss.plan_hash_value, ss.executions_delta,
       ss.elapsed_time_delta, ss.cpu_time_delta, ss.buffer_gets_delta
FROM dba_hist_snapshot s
JOIN dba_hist_sqlstat ss ON ss.snap_id = s.snap_id AND ss.dbid = s.dbid AND ss.instance_number = s.instance_number
WHERE s.dbid = &v_dbid
  AND s.instance_number = &v_inst_id
  AND ss.con_id = &v_con_id
  AND s.snap_id BETWEEN &v_snap1 AND &v_snap2
ORDER BY ss.elapsed_time_delta DESC
;

PROMPT Done. Replace &&dbid, &&inst_id, &&con_id, &&snap1 and &&snap2 with values (or run with ACCEPT).
