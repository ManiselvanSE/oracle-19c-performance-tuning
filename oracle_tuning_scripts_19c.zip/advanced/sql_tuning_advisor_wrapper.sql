-- sql_tuning_advisor_wrapper.sql
-- Simple wrapper to submit SQL Tuning Advisor task for a given SQL_ID in a PDB (CON_ID)
-- Replace &&sql_id and &&con_id
SET SERVEROUTPUT ON
DECLARE
  l_task_name VARCHAR2(100);
  l_task_id   NUMBER;
BEGIN
  l_task_name := 'STA_'||TO_CHAR(SYSDATE,'YYYYMMDD_HH24MISS')||'_PID'||USERENV('SID');
  l_task_id := DBMS_SQLTUNE.CREATE_TUNING_TASK(
    sql_id => '&&sql_id',
    task_name => l_task_name,
    scope => DBMS_SQLTUNE.scope_comprehensive,
    time_limit => 60,
    work_dir => NULL,
    description => 'Tuning task from SQL*Plus wrapper');
  DBMS_SQLTUNE.EXECUTE_TUNING_TASK(task_name => l_task_name);
  DBMS_OUTPUT.PUT_LINE('Task created/ran: '||l_task_name);
  -- To view recommendations:
  -- SELECT DBMS_SQLTUNE.REPORT_TUNING_TASK(''||l_task_name||'') FROM DUAL;
END;
/
