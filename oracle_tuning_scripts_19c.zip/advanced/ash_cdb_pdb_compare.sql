-- ash_cdb_pdb_compare.sql
-- Compare ASH activity between CDB$ROOT and a PDB over a time window.
-- Usage: set start_time and end_time (timestamps) and set v_con_id for PDB (1 is CDB$ROOT usually)
DEFINE v_start = "TO_DATE('&&start_time','YYYY-MM-DD HH24:MI:SS')"
DEFINE v_end = "TO_DATE('&&end_time','YYYY-MM-DD HH24:MI:SS')"
DEFINE v_pdb_con_id = '&&pdb_con_id'

-- CDB$ROOT activity
SELECT 'CDB_ROOT' user_env, event, COUNT(*) samples
FROM v$active_session_history ash
WHERE sample_time BETWEEN &v_start AND &v_end
  AND con_id = 1
GROUP BY event
ORDER BY samples DESC;

-- PDB activity
SELECT 'PDB_'||&v_pdb_con_id user_env, event, COUNT(*) samples
FROM v$active_session_history ash
WHERE sample_time BETWEEN &v_start AND &v_end
  AND con_id = &v_pdb_con_id
GROUP BY event
ORDER BY samples DESC;

PROMPT Done.
