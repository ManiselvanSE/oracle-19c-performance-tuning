-- awr_compare_snapshots.sql
-- Simple AWR compare: top wait events delta between two snapshots for a CON_ID
DEFINE v_snap1 = '&&snap1'
DEFINE v_snap2 = '&&snap2'
DEFINE v_con_id = '&&con_id'
SELECT event, SUM(ends) ends_sum
FROM dba_hist_event_histogram eh
WHERE snap_id IN (&v_snap1, &v_snap2)
  AND con_id = &v_con_id
GROUP BY event
ORDER BY ends_sum DESC;
