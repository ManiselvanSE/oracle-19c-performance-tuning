-- awr_pdb_load_profile.sql
-- Load profile per PDB (con_id) between two snapshots
DEFINE v_snap1 = '&&snap1'
DEFINE v_snap2 = '&&snap2'
SELECT con_id, SUM(db_time_delta) db_time, SUM(cpu_time_delta) cpu_time, SUM(non_idl_wait_time_delta) wait_time
FROM dba_hist_sys_time_model
WHERE snap_id BETWEEN &v_snap1 AND &v_snap2
GROUP BY con_id
ORDER BY db_time DESC;
