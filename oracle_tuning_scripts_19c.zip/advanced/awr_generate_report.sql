-- awr_generate_report.sql
-- Generate AWR report for specified dbid/instance/snap range and CON_ID (PDB aware)
-- Replace &&dbid, &&inst_num, &&snap1, &&snap2, &&con_id before running or use ACCEPT
DEFINE v_dbid = '&&dbid'
DEFINE v_inst = '&&inst_num'
DEFINE v_snap1 = '&&snap1'
DEFINE v_snap2 = '&&snap2'
DEFINE v_con = '&&con_id' -- optional: some AWR report tools filter by CON_ID

-- Uses DBMS_WORKLOAD_REPOSITORY to create a report text file in the DB server
SET SERVEROUTPUT ON SIZE 1000000
DECLARE
  l_report CLOB;
BEGIN
  l_report := DBMS_WORKLOAD_REPOSITORY.AWR_REPORT_TEXT(
    dbid => TO_NUMBER(&v_dbid),
    inst_num => TO_NUMBER(&v_inst),
    begin_snap => TO_NUMBER(&v_snap1),
    end_snap => TO_NUMBER(&v_snap2),
    options => null);
  DBMS_OUTPUT.PUT_LINE('AWR report generated (text).');
  -- Note: to spool to file, run REPORT in SQL*Plus with SPOOL; or use DBMS_FILE_TRANSFER on server.
END;
/
