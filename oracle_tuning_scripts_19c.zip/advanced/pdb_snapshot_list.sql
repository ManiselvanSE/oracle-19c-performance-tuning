-- pdb_snapshot_list.sql
-- List AWR snapshots and associated CON_ID (PDB). Useful for picking snapshot ranges per PDB.
SELECT snap_id, begin_interval_time, end_interval_time, dbid, instance_number, con_id
FROM dba_hist_snapshot
ORDER BY snap_id DESC
FETCH FIRST 200 ROWS ONLY;
