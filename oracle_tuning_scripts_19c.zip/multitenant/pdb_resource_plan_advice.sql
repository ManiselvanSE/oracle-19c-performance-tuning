-- pdb_resource_plan_advice.sql
-- Show resource plan assignments and PDB resource groups (if using Database Resource Manager)
SELECT d.resource_name, c.con_id, c.name pdb_name, d.plan
FROM cdb_pdbs c
LEFT JOIN (SELECT * FROM dba_rsrc_plan WHERE rownum < 100) d ON 1=1
ORDER BY c.con_id;
