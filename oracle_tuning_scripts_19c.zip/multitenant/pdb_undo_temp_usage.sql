-- pdb_undo_temp_usage.sql
-- Check TEMP and UNDO usage per PDB (approximation via v$sort_usage and v$rollstat if available)
-- TEMP usage (active sessions using temp)
SELECT con_id, COUNT(*) temp_sessions
FROM v$sort_usage
GROUP BY con_id
ORDER BY temp_sessions DESC;

-- UNDO tablespace usage per PDB (requires monitoring views or queries on dba_hist_undo_stats)
SELECT con_id, SUM(tu_total) total_undo
FROM dba_hist_undo_stats
GROUP BY con_id
ORDER BY total_undo DESC;
