-- pdb_service_mapping.sql
-- Map services to PDBs (helps identify service-based workloads)
SELECT name service_name, network_name, pdb, con_id
FROM dba_services
ORDER BY pdb, name;
