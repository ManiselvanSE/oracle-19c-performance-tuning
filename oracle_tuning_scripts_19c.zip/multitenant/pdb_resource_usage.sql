-- pdb_resource_usage.sql
-- Show CPU/DB_TIME/IO per PDB between two AWR snapshots
DEFINE snap1 = '&&snap1'
DEFINE snap2 = '&&snap2'
SELECT con_id, SUM(db_time_delta) db_time, SUM(cpu_time_delta) cpu_time, SUM(phy_read_requests_delta) phy_reads
FROM dba_hist_sys_time_model
WHERE snap_id BETWEEN &snap1 AND &snap2
GROUP BY con_id
ORDER BY db_time DESC;
