-- pdb_memory_advice.sql
-- PGA/SGA related metrics per PDB (PGA is instance-level; this gives SGA and shared pool relevance per PDB via v$ views)
SELECT con_id, SUM(pga_alloc_mem) pga_alloc, SUM(pga_freeable_mem) pga_freeable
FROM v$process p JOIN v$session s ON p.addr = s.paddr
GROUP BY con_id
ORDER BY pga_alloc DESC;
