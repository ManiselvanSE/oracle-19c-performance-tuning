-- pdb_ash_hot_sqls.sql
-- Top SQLs by samples in ASH for a given PDB in a time window
DEFINE pdb = '&&con_id'
DEFINE start_time = "TO_DATE('&&start_time','YYYY-MM-DD HH24:MI:SS')"
DEFINE end_time = "TO_DATE('&&end_time','YYYY-MM-DD HH24:MI:SS')"
SELECT sql_id, COUNT(*) samples
FROM v$active_session_history ash
WHERE con_id = &pdb
  AND sample_time BETWEEN &start_time AND &end_time
GROUP BY sql_id
ORDER BY COUNT(*) DESC
FETCH FIRST 50 ROWS ONLY;
