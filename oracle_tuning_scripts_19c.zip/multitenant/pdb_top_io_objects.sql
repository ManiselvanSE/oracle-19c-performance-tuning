-- pdb_top_io_objects.sql
-- Top objects by physical reads/writes per PDB (using DBA_HIST_SEG_STAT or v$segstat depending on privileges)
SELECT con_id, owner, object_name, SUM(phyrds) phyrds, SUM(phywrts) phywrts
FROM dba_hist_seg_stat
GROUP BY con_id, owner, object_name
ORDER BY SUM(phyrds) DESC
FETCH FIRST 100 ROWS ONLY;
