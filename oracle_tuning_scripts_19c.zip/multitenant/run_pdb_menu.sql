-- run_pdb_menu.sql
PROMPT Multitenant (PDB) Diagnostics Menu
PROMPT 1. List PDBs and status
PROMPT 2. PDB resource usage between AWR snapshots
PROMPT 3. PDB top IO objects
PROMPT 4. PDB AWR SQL diff (snapshots)
PROMPT 5. PDB ASH hot SQLs
PROMPT 6. PDB service mapping
PROMPT 7. PDB undo/temp usage
PROMPT 8. Exit
ACCEPT choice PROMPT 'Choice: '
COLUMN script NEW_VALUE v_script
SELECT CASE '&choice'
WHEN '1' THEN 'multitenant/pdb_list_and_status.sql'
WHEN '2' THEN 'multitenant/pdb_resource_usage.sql'
WHEN '3' THEN 'multitenant/pdb_top_io_objects.sql'
WHEN '4' THEN 'multitenant/pdb_awr_sql_diff.sql'
WHEN '5' THEN 'multitenant/pdb_ash_hot_sqls.sql'
WHEN '6' THEN 'multitenant/pdb_service_mapping.sql'
WHEN '7' THEN 'multitenant/pdb_undo_temp_usage.sql'
ELSE 'EXIT'
END script FROM dual;
PROMPT Running &v_script ...
@&v_script
