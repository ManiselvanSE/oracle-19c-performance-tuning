-- pdb_list_and_status.sql
-- List PDBs, CON_ID, open mode, and common services
COLUMN pdb_name FORMAT A30
SELECT con_id, name pdb_name, open_mode, cdb, common
FROM v$pdbs
ORDER BY con_id;
