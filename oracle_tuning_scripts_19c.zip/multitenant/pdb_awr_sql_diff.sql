-- pdb_awr_sql_diff.sql
-- Compare top SQL between two snapshots for a given PDB (CON_ID)
DEFINE con_id = '&&con_id'
DEFINE snap1 = '&&snap1'
DEFINE snap2 = '&&snap2'
SELECT ss.sql_id, ss.plan_hash_value, SUM(ss.elapsed_time_delta) elapsed_time_delta, SUM(ss.executions_delta) execs
FROM dba_hist_sqlstat ss
JOIN dba_hist_snapshot s ON ss.snap_id = s.snap_id AND ss.dbid = s.dbid AND ss.instance_number = s.instance_number
WHERE ss.con_id = &con_id
  AND s.snap_id BETWEEN &snap1 AND &snap2
GROUP BY ss.sql_id, ss.plan_hash_value
ORDER BY SUM(ss.elapsed_time_delta) DESC
FETCH FIRST 50 ROWS ONLY;
