# Oracle 19c Performance Tuning Scripts
This package contains curated SQL scripts for Oracle 19c Multitenant performance monitoring and tuning.
Run with: `sqlplus / as sysdba` and then `@run_menu.sql`.
