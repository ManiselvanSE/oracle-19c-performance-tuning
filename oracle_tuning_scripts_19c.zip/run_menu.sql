PROMPT Oracle 19c Performance Tuning Menu
PROMPT 1. AWR Top SQLs
PROMPT 2. ASH Top Waits
PROMPT 3. Real-time Sessions
PROMPT 4. IO Summary
PROMPT 5. Health Check
PROMPT Enter your choice:
ACCEPT choice PROMPT 'Choice: '
COLUMN script NEW_VALUE v_script
SELECT CASE '&choice' 
WHEN '1' THEN 'awr/awr_top_sqls.sql'
WHEN '2' THEN 'ash/ash_top_waits.sql'
WHEN '3' THEN 'realtime_monitoring/moats.sql'
WHEN '4' THEN 'io_waits/file_io_summary.sql'
WHEN '5' THEN 'instance_health/db_health_check.sql'
END script FROM dual;
PROMPT Running &v_script ...
@&v_script
